DigitalNest — Complete Source

This archive contains the source files downloaded from the live AppDeploy project.

Project structure:
- src/       React + TypeScript frontend
- backend/   AppDeploy backend and realtime handlers
- public/    Static public assets
- tests/     AppDeploy test workflows
- root files Vite, TypeScript, Tailwind and package configuration

The archive is a source snapshot; it does not include deployed secrets, hosted database contents, or a local copy of the AppDeploy platform services. Keep any credentials in environment variables and never commit them to source control.

To install dependencies in a compatible Node.js environment, run: npm install
To start the Vite development server, run: npm run dev
